from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/result', methods=['POST'])
def result():
    preference = request.form['preference']
    age = request.form['age']
    mood = request.form['mood']
    genre = request.form['genre']

    recommendation = ""

    if age == "18-30":
        if preference == "pelicula":
            if mood == "Feliz":
                if genre == "Comedia romantica":
                    recommendation = "The Kissing Booth, Crazy Rich Asians"
                elif genre == "Accion":
                    recommendation = "Guardians of the Galaxy, Spiderman: No Way Home"
                elif genre == "Drama":
                    recommendation = "Gifted, The Pursuit of Happyness"
                elif genre == "Comedia":
                    recommendation = "Grown Ups 1, White Chicks"
            elif mood == "Triste":
                if genre == "Comedia romantica":
                    recommendation = "One Day, Five Feet Apart"
                elif genre == "Accion":
                    recommendation = "Logan (2017), Gladiator"
                elif genre == "Drama":
                    recommendation = "Hachi: A Dog's Tale, Society of the Snow"
                elif genre == "Comedia":
                    recommendation = "We Are the Millers, Pitch Perfect 1"
            elif mood == "Enamorado":
                if genre == "Comedia romantica":
                    recommendation = "Your Place or Mine, The Proposal"
                elif genre == "Accion":
                    recommendation = "Mr. and Mrs. Smith, Love and Monsters"
                elif genre == "Drama":
                    recommendation = "A Marriage Story, Call Me by Your Name"
                elif genre == "Comedia":
                    recommendation = "Friends with Benefits, Just Go with It"
        elif preference == "serie":
            if mood == "Feliz":
                if genre == "Comedia romantica":
                    recommendation = "Emily in Paris, Boo Bitch"
                elif genre == "Accion":
                    recommendation = "Stranger Things, The Mandalorian"
                elif genre == "Drama":
                    recommendation = "Andor, La Casa de Papel"
                elif genre == "Comedia":
                    recommendation = "Brooklyn Nine-Nine, Modern Family"
            elif mood == "Triste":
                if genre == "Comedia romantica":
                    recommendation = "Euphoria, Moon Lovers: Scarlet Heart Ryeo"
                elif genre == "Accion":
                    recommendation = "The Witcher, The Sympathizer"
                elif genre == "Drama":
                    recommendation = "The Queen's Gambith, The Crown"
                elif genre == "Comedia":
                    recommendation = "Cobra Kai, Peaky Blinders"
            elif mood == "Enamorado":
                if genre == "Comedia romantica":
                    recommendation = "Never Have I Ever, The Summer I Turned Pretty"
                elif genre == "Accion":
                    recommendation = "The Umbrella Academy, The End of the F*ing World"
                elif genre == "Drama":
                    recommendation = "Control Z, Bridgerton"
                elif genre == "Comedia":
                    recommendation = "The Artful Dodger, Love Victor"

    elif age == "30-50":
        if preference == "pelicula":
            if mood == "Feliz":
                if genre == "Comedia romantica":
                    recommendation = "Grease"
                elif genre == "Accion":
                    recommendation = "Star War: A New Hope, The Expendables"
                elif genre == "Drama":
                    recommendation = "The Pianist, The Green Mile"
                elif genre == "Comedia":
                    recommendation = "My Best Friend's Wedding, Hot Shots!"
            elif mood == "Triste":
                if genre == "Comedia romantica":
                    recommendation = "The Notebook, Sweet November"
                elif genre == "Accion":
                    recommendation = "Saving Private Ryan, Bicentennial Man"
                elif genre == "Drama":
                    recommendation = "Schindler's List, Life is Beautiful"
                elif genre == "Comedia":
                    recommendation = "The Naked Gun, Trading Places"
            elif mood == "Enamorado":
                if genre == "Comedia romantica":
                    recommendation = "50 First Dates, Four Weddings and a Funeral"
                elif genre == "Accion":
                    recommendation = "The Last of the Mohicans, The Bodyguard"
                elif genre == "Drama":
                    recommendation = "Flash Dance, Romeo + Julieta"
                elif genre == "Comedia":
                    recommendation = "You've Got Mail, Pretty Woman"
        elif preference == "serie":
            if mood == "Feliz":
                if genre == "Comedia romantica":
                    recommendation = "Grace and Frankie, Jane the Virgin"
                elif genre == "Accion":
                    recommendation = "Breaking Bad, Obi Wan"
                elif genre == "Drama":
                    recommendation = "The Sopranos, The House of Flowers"
                elif genre == "Comedia":
                    recommendation = "Wednesday, The War Next Door"
            elif mood == "Triste":
                if genre == "Comedia romantica":
                    recommendation = "This Is Us, Hi Bye Mama"
                elif genre == "Accion":
                    recommendation = "Masters of the Air, Mr Sunshine"
                elif genre == "Drama":
                    recommendation = "Crash Landing on You, YOU"
                elif genre == "Comedia":
                    recommendation = "Dead to Me, Modern Family"
            elif mood == "Enamorado":
                if genre == "Comedia romantica":
                    recommendation = "Sex and the City, Hometown Cha Cha Cha"
                elif genre == "Accion":
                    recommendation = "Bodyguard, Vagabond"
                elif genre == "Drama":
                    recommendation = "Scream Queens, Downton Abbey"
                elif genre == "Comedia":
                    recommendation = "How I Met Your Mother, The Good Place"

    return render_template('index.html', movie=recommendation)

if __name__ == '__main__':
    app.run(debug=True)
