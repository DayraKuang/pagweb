document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        const mood = document.getElementById('mood').value;
        const age = document.getElementById('age').value;
        const preference = document.getElementById('preference').value;
        const genre = document.getElementById('genre').value;

        if (!mood || !age || !preference || !genre) {
            alert('Por favor, completa todos los campos.');
            event.preventDefault();
        }
    });

    // Funcionalidad adicional
    const moodInput = document.getElementById('mood');
    moodInput.addEventListener('input', function() {
        console.log(`Mood: ${moodInput.value}`);
    });

    const ageInput = document.getElementById('age');
    ageInput.addEventListener('input', function() {
        console.log(`Age: ${ageInput.value}`);
    });

    const preferenceSelect = document.getElementById('preference');
    preferenceSelect.addEventListener('change', function() {
        console.log(`Preference: ${preferenceSelect.value}`);
    });

    const genreInput = document.getElementById('genre');
    genreInput.addEventListener('input', function() {
        console.log(`Genre: ${genreInput.value}`);
    });
});
